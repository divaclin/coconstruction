<?php

$currentType = //"B" || "T" || "G" ;
$currentData = //json_encode( the datas )  ;

echo "<script>\
var currentType = ". $currentType ."; \
var currentData = ". $currentData ."; \
</script>";

?>
